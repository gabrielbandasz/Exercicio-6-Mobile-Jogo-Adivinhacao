package br.ulbra.jogoadivinhacao

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.abs
import kotlin.random.Random

class JogoActivity : AppCompatActivity() {

    private var nome = ""
    private var maximo = 50
    private var secreto = 0
    private var tentativas = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_jogo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        nome = intent.getStringExtra("nome") ?: ""
        maximo = intent.getIntExtra("maximo", 50)
        secreto = Random.nextInt(1, maximo + 1)

        val txtBemVindo = findViewById<TextView>(R.id.txtBemVindo)
        val edtPalpite = findViewById<EditText>(R.id.edtPalpite)
        val btnChutar = findViewById<Button>(R.id.btnChutar)
        val txtDica = findViewById<TextView>(R.id.txtDica)
        val txtTentativas = findViewById<TextView>(R.id.txtTentativas)
        val btnNovamente = findViewById<Button>(R.id.btnNovamente)

        txtBemVindo.text = "$nome, pensei num número de 1 a $maximo!"

        btnChutar.setOnClickListener {
            val palpite = edtPalpite.text.toString().toIntOrNull()
            if (palpite == null || palpite < 1 || palpite > maximo) {
                edtPalpite.error = "Digite um número de 1 a $maximo"
                return@setOnClickListener
            }

            tentativas++
            txtTentativas.text = "Tentativas: $tentativas"

            if (palpite == secreto) {
                txtDica.text = "Acertou! $nome acertou em $tentativas tentativas!"
                btnChutar.isEnabled = false
                edtPalpite.isEnabled = false
                btnNovamente.visibility = View.VISIBLE
            } else {
                val diferenca = abs(palpite - secreto)
                val temperatura = if (diferenca <= maximo / 10) "Quente" else "Frio"
                val direcao = if (secreto > palpite) "MAIOR" else "MENOR"
                txtDica.text = "$temperatura! O número é $direcao."
                edtPalpite.text.clear()
            }
        }

        btnNovamente.setOnClickListener {
            finish()
        }
    }
}
